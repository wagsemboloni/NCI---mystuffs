/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayliststriggerapplication;

/**
 *
 * @author fsheridan
 */
public class QuestionApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        QuestionGUI myGUI = new QuestionGUI();
        myGUI.setVisible(true);
    }
}
