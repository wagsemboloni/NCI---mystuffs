/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package employeefileio;

/**
 *
 * @author carole
 */
public class Engineer extends Employee{
    private double salary;
    
    public Engineer (String name, int empId, double salary){
        super(name, empId);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    @Override
    public String getDetails(){
        return super.getDetails() + "\nEmployee Salary:"+salary;
    }
}
