/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fileiowithtext;

/**
 *
 * @author fsheridan
 */
public class PetitionApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PetitionGUI myGUI = new PetitionGUI();
        myGUI.setVisible(true);
    }
}
